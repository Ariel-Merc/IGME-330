interface ColorStop {
    percent: number;
    color: string;
}

export {ColorStop};