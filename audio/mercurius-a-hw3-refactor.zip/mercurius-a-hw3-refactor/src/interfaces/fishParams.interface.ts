interface FishParams {
    image: string;
    radius: number;
}

export {FishParams};