interface RippleParams {
    x: number;
    y: number;
    intensity: number;
}

export {RippleParams};