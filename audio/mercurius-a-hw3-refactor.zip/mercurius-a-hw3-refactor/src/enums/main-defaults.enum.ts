enum MainDefaults {
    Sound1 = "./media/The Forests of Gliese.mp3"
}

export {MainDefaults};