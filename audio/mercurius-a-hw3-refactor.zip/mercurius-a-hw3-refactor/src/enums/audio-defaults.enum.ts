enum AudioDefaults {
    Gain = 0.5,
    NumSamples = 256
}

export {AudioDefaults};